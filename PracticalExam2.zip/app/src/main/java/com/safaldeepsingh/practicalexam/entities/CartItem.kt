package com.safaldeepsingh.practicalexam.entities

class CartItem (
    val product: Product,
    var quantity: Int
        ){

}